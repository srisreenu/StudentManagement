﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace student
{
    class Program
    {
        static void Main(string[] args)
        {
            int cnt = 0;
            int flag = 1;
            student[] ob = new student[100];
            while(flag == 1)
            {
                Console.Write("\n"+"1.ADD STUDENT DETAILS");
                Console.Write("\n" + "2.display");
                Console.Write("\n" + "3.EXIT");
                Console.Write("\n" + "4.SEARCH BY ROLL NUMBER");
                Console.Write("\n" + "5.SEARCH BYE FNAME");
                Console.Write("\n" + " 6.SEARCH BY LAST NAME");
                Console.Write("\n" + "7.DELETE A STUDENT RECORD");
                Console.Write("\n" + "8.DISPLAY THE NUMBER OF STUDENTS");
                Console.Write("\n"+"ENTER YOU CHOICE:::");
                

                int ch = int.Parse(Console.ReadLine());
                switch (ch)
                {
                    case 1: ob[cnt] = new student();cnt++; break;
                    default: Console.WriteLine("ENTER THE CORRECT CHOICE");break;
                    case 2:
                        for (int i = 0; i < cnt; i++)
                        {
                            ob[i].display();
                        };
                        break;
                    case 3: flag = 0;break;
                    case 4:
                        Console.WriteLine("ENTER THE ROLL NUM TO BE SEARCHED");
                        int rval = int.Parse(Console.ReadLine());
                        int x = 0;
                        for (int i = 0; i<cnt;i++)
                        {
                            if(ob[i] !=null)
                            {
                                if (ob[i].rollnum == rval)
                                {
                                    ob[i].display();
                                    x = 1;
                                    break;
                                }
                            }
                        }
                        if (x == 0)
                            Console.WriteLine("roll num not found");
                        break;
                    case 5:
                        Console.WriteLine("ENTER THE fname TO BE SEARCHED");
                        string fval = Console.ReadLine();
                        int y = 0;
                        for(int i =0; i<cnt; i++)
                        {
                            if (ob[i].fname == fval)
                            {
                                ob[i].display();
                                y = 1;
                            }
                        };
                        if(y == 0)
                            Console.WriteLine("first name  not found");
                        break;
                    case 6:
                        Console.WriteLine("ENTER THE LAST NAMETO BE SEARCHED");
                        string lval = Console.ReadLine();
                        int z = 0;
                        for (int i = 0; i < cnt; i++)
                        {
                            if (ob[i].lname == lval)
                            {
                                ob[i].display();
                                z = 1;
                            }
                        };
                        if(z==0)
                            Console.WriteLine("last name  not found");
                        break;
                    case 7:
                        Console.WriteLine("ENTER THE STUDENT ROLLNUMBER TO BE DELETED");
                        int srval = int.Parse(Console.ReadLine());
                        for(int i =0; i< cnt; i++)
                        {
                            if (ob[i].rollnum == srval)
                            {
                                ob[i] = null;
                                GC.Collect();
                                GC.WaitForPendingFinalizers();
                                cnt--;
                            }
                        }
                        for(int j = 0; j< cnt; j++)
                        {
                            if(ob[j] == null)
                            {
                                ob[j] = ob[j + 1];
                                ob[j + 1] = null;
                            }
                        }
                        break;
                    
                    case 8:
                        Console.WriteLine("THE NUMBER OF STUDENTS ARE = " + cnt);break;

                }
            }
        }
        
        
        
        
    }
}
