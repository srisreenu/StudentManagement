﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace student
{
    class student
    {
        public string fname, lname, sec;
        public int rollnum, age;
        public float grade;

        public student()
        {
            Console.WriteLine();
            Console.Write("ENTER THE STUDENT FIRST NAME:      ");
            fname = Console.ReadLine();
            Console.Write("ENTER THE STUDENT LAST NAME:       ");
            lname = Console.ReadLine();
            Console.Write("ENTER THE STUDENT  ROLL NUMBER:    ");
            rollnum = int.Parse(Console.ReadLine());
            Console.Write("ENTER MALE OF FEMALE:          ");
            sec = Console.ReadLine();
            Console.Write("ENTER THE AGE OF THE STUDENT:  ");
            age = int.Parse(Console.ReadLine());
            Console.Write("ENTER THE STUDENT GRADE:           ");
            grade = float.Parse(Console.ReadLine());
        }
        public void display()
        {
            Console.WriteLine("__________________________________________________________________________________");
            Console.Write("\n"+" THE STUDENT FIRST NAME:                  "  +fname);
           
            Console.Write("\n"+"ENTER THE STUDENT LAST NAME:              "  +lname);
            Console.Write("\n"+"THE STUDENT IS                            "  +sec);
            Console.Write("\n"+"THE AGE OF THE STUDENT IS:                "  +age);
            Console.Write("\n"+"THE STUDENT  ROLL NUMBER:                 "  +rollnum);
 
            Console.Write("\n"+"THE STUDENT GRADE:                        "  +grade);
   
            Console.WriteLine();
        }
       

    }
}
